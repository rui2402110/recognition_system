// コピーボタンを押すとコピーできる関数
function copyButton(elementId) {
    var element = document.getElementById(elementId);
    navigator.clipboard.writeText(element.textContent)
}

// エクスポートの関数　ほぼscriptjsと同じコードなのでコメント割愛
function save(text) {
    var day = new Date();
    filename = `mojiokosi_log${day.getFullYear()}_${(day.getMonth() + 1)}_${day.getDate()}.txt`;

    const blob = new Blob([text], { type: "text/plain" });

    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url;
    a.download = filename;

    document.body.appendChild(a);
    a.click();

    document.body.removeChild(a);
    URL.revokeObjectURL(url);
}

// 削除の関数（サーバー連携版）
async function log_delete(id) {
    try {
        // まず現在のデータを取得して確認用のメッセージを作成
        const speechResponse = await fetch(`./speech_data.json`);
        const speechData = await speechResponse.json();

        // 削除対象のデータを見つける（数値として比較）
        const numericSearchId = parseInt(id, 10);
        const targetItem = speechData.find(item => parseInt(item.id, 10) === numericSearchId);

        if (!targetItem) {
            alert('指定されたIDのデータが見つかりません');
            return;
        }

        const confirmMessage = `以下のデータを削除しますか？\n\n"${targetItem.text.substring(0, 50)}${targetItem.text.length > 50 ? '...' : ''}"`;

        const ok = confirm(confirmMessage);

        if (!ok) {
            alert('削除は行いませんでした');
            return;
        }

        // サーバーに削除リクエストを送信
        const deleteResponse = await fetch(`/api/strings/${numericSearchId}`, {
            method: 'DELETE',
            headers: {
                'Content-Type': 'application/json'
            }
        });

        const deleteResult = await deleteResponse.json();

        if (deleteResponse.ok && deleteResult.success) {
            alert(`データが削除されました\n残り件数: ${deleteResult.remainingCount}件`);

            // ログを再描画
            log();
        } else {
            alert(`削除に失敗しました: ${deleteResult.error || deleteResult.message}`);
        }

    } catch (error) {
        console.error('削除処理でエラーが発生しました:', error);
        alert('削除処理中にエラーが発生しました。詳細はコンソールを確認してください。');
    }
}

// ログを表示する関数
async function log() {
    // htmlの要素を取得
    let log_elm = document.getElementById("logData");
    // jsonにフェッチする
    const speechResponse = await fetch(`./speech_data.json`);
    // jsonのデータをjsで使えるように処理
    const prefs = await speechResponse.json();

    // これから使う変数を定義
    const divStrs = [];
    var count = 0;

    // for文でjsonのデータを全て配列に格納
    for (const pref of prefs) {
        // ログデータに順番を振り分けるためにcountを1増やす
        count++;
        divStrs.push(`
            <div>
                <label>ログデータ${count}</label>
                <div>
                    <button id='export${count}' class="btn-svg small" onclick="handleClick('基本ボタン')"><svg> <rect x="2" y="2" width="146" height="36"></rect></svg><span>エクスポート</span></button> 
                    <button onclick='copyButton(\"${pref.id}\")'class="btn-svg small" onclick="handleClick('基本ボタン')"><svg><rect x="2" y="2" width="146" height="36"></rect></svg><span>コピー</span></button> 
                    <button id='delete${count}' class="btn-svg small" onclick="handleClick('基本ボタン')"><svg> <rect x="2" y="2" width="146" height="36"></rect></svg><span>ログの削除</span></button> 
                </div>
                <!--  -->
                <p id="${pref.id}" class="log_result">${pref.text}</p>
            </div>
        `);
    }

    // HTMLを設定
    log_elm.innerHTML = divStrs.join('');

    // エクスポートボタンのイベントリスナーを設定
    for (let i = 1; i <= count; i++) {
        // count分のexportを取得
        const exportButton = document.getElementById(`export${i}`);
        const deleteButton = document.getElementById(`delete${i}`);
        // textを取得(0から始まっているので引く)
        const textElement = document.getElementById(prefs[i - 1].id);
        // 修正: IDを正しく取得
        const currentId = prefs[i - 1].id;

        // exportとtextのどちらもtrueになった場合saveメソッドを実行
        if (exportButton && textElement) {
            exportButton.addEventListener("click", () => {
                save(textElement.textContent);
            });
        }
        // deleteボタンのイベントリスナー（IDを直接使用）
        if (deleteButton) {
            deleteButton.addEventListener("click", () => {
                log_delete(currentId);
            });
        }
    }
}

// logを起動しちゃう
log();