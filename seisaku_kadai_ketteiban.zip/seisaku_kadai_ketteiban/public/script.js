// SpeechRecognitionの参考資料 https://qiita.com/hmmrjn/items/4b77a86030ed0071f548

// 音声文字起こしツールのメインクラス
class SpeechTranscriptionTool {
    constructor() {
        // - window.SpeechRecognition は 音声認識を使うためのオブジェクト
        // window.webkitSpeechRecognition は 一部のブラウザでの互換用
        // new SpeechRecognition() で 音声認識機能を作成
        window.SpeechRecognition = window.SpeechRecognition || window.webkitSpeechRecognition;
        this.recognition = new SpeechRecognition();

        this.initializeRecognition();
        this.bindEvents();
    }

    // 音声認識の初期設定
    initializeRecognition() {
        this.recognition.lang = 'ja-JP'; // 日本語の認識
        this.recognition.continuous = true; // 連続認識
        this.recognition.interimResults = true; // 途中結果も取得

        // event.results には 認識したテキストが入っている
        // event.results[i][0].transcript で 個々のテキストを取得
        // document.getElementById("result").textContent = transcript で 画面に表示
        this.recognition.onresult = (event) => {
            this.handleRecognitionResult(event);
        };

        // エラーハンドリング
        this.recognition.onerror = (event) => {
            console.error('音声認識エラー:', event.error);
            alert('音声認識でエラーが発生しました: ' + event.error);
        };

        this.recognition.onend = () => {
            console.log('音声認識が終了しました');
            // 停止時にボタンの状態をリセット
            this.resetButtonStates();
        };
    }

    // 音声認識結果の処理
    handleRecognitionResult(event) {
        var transcript = "";
        for (var i = 0; i < event.results.length; i++) {
            transcript += event.results[i][0].transcript;

            if (event.results[i].isFinal) {
                transcript += "\n";
            } else {
                transcript += " ";
            }
        }
        console.log("システムが読み取っている文章「" + transcript + "」");

        const resultElement = document.getElementById("result");
        resultElement.textContent = transcript;

        // スクロールを一番下に移動
        resultElement.scrollTop = resultElement.scrollHeight;
    }

    // 音声認識を開始
    startRecognition() {
        try {
            // ボタンの状態を変更
            const startBtn = document.getElementById("start");
            const stopBtn = document.getElementById("stop");
            
            // 開始ボタンを無効化
            startBtn.disabled = true;
            startBtn.innerHTML = '<span>文字起こし開始</span>';
            startBtn.style.opacity = '0.6';
            startBtn.style.cursor = 'not-allowed';
            
            // 停止ボタンを有効化
            stopBtn.disabled = false;
            stopBtn.style.opacity = '1';
            stopBtn.style.cursor = 'pointer';

            this.recognition.start();
            console.log('音声認識を開始しました');

            // move_itemクラスの要素にred_colorクラスを追加し、gure_colorクラスを削除
            const moveItem = document.querySelector('.move_item');
            if (moveItem) {
                moveItem.classList.remove('gure_color');
                moveItem.classList.add('red_color');
            }

            // toggleElementのテキストを変更
            const toggleElement = document.getElementById('toggleElement');
            if (toggleElement) {
                toggleElement.innerHTML = 'RECORDING! &emsp;  &emsp; &emsp;  &emsp;  &emsp;  &emsp;   RECORDING! &emsp;  &emsp; &emsp;  &emsp;  &emsp;  &emsp;   RECORDING! &emsp;  &emsp; &emsp;  &emsp;  &emsp;  &emsp; RECORDING! &emsp;  &emsp; &emsp;  &emsp;  &emsp;  &emsp; ';
            }
        } catch (error) {
            console.error('音声認識の開始に失敗しました:', error);
            alert('音声認識の開始に失敗しました');
            // エラー時にボタンの状態をリセット
            this.resetButtonStates();
        }
    }

    // 音声認識を停止
    stopRecognition() {
        this.recognition.stop();
        
        // ボタンの状態をリセット
        this.resetButtonStates();

        // move_itemクラスの要素にgure_colorクラスを追加し、red_colorクラスを削除
        const moveItem = document.querySelector('.move_item');
        if (moveItem) {
            moveItem.classList.remove('red_color');
            moveItem.classList.add('gure_color');
        }

        // toggleElementのテキストを変更
        const toggleElement = document.getElementById('toggleElement');
        if (toggleElement) {
            toggleElement.innerHTML = 'NO RECORDING &emsp;  &emsp; &emsp;  &emsp;  &emsp;  &emsp;   NO RECORDING &emsp; &emsp;  &emsp;  &emsp;  &emsp;   &emsp;  NO RECORDING &emsp;  &emsp; &emsp;  &emsp;  &emsp;  &emsp; NO RECORDING &emsp;  &emsp; &emsp;  &emsp;  &emsp;  &emsp;  ';
        }

        // 停止したタイミングでサーバーにデータを送る
        const resultText = document.getElementById("result").textContent;
        if (resultText.trim()) {
            this.sendToServer(resultText);
        } else {
            console.log('送信するテキストがありません');
        }
    }

    // ボタンの状態をリセットする関数
    resetButtonStates() {
        const startBtn = document.getElementById("start");
        const stopBtn = document.getElementById("stop");
        
        // 開始ボタンを有効化
        startBtn.disabled = false;
        startBtn.innerHTML = '<span>文字起こし開始</span>';
        startBtn.style.opacity = '1';
        startBtn.style.cursor = 'pointer';
        
        // 停止ボタンを無効化
        stopBtn.disabled = true;
        stopBtn.style.opacity = '0.6';
        stopBtn.style.cursor = 'not-allowed';
    }

    // コピーボタンの参考資料 https://blog.future.ad.jp/%E3%82%B3%E3%83%94%E3%83%9A%E3%81%A7%E4%BD%BF%E3%81%88%E3%82%8Bjavascript%E3%81%A7%E3%82%B3%E3%83%94%E3%83%BC%E3%83%9C%E3%82%BF%E3%83%B3%E3%82%92%E4%BD%9C%E6%88%90%E3%81%99%E3%82%8B%E6%96%B9%E6%B3%95

    // 指定された要素のテキストをクリップボードにコピー
    copyButton(elementId) {
        // 引数で得たIDの要素のテキストを取得
        var element = document.getElementById(elementId);

        // 上記要素をクリップボードにコピーする
        navigator.clipboard.writeText(element.textContent)
            .then(() => {
                console.log('テキストがコピーされました');
                alert('テキストがコピーされました');
            })
            .catch(err => {
                console.error('コピーに失敗しました:', err);
                alert('コピーに失敗しました');
            });
    }

    // テキストファイルのエクスポート参考資料 https://zenn.dev/snake12379/articles/8c4491dc13caa3

    // テキストをファイルとして保存
    save(text) {
        // ダウンロードするファイルに日付をつけたかったので(おしゃれ！)Dateを作成し、ファイルの名前を設定
        var day = new Date();
        var filename = `mojiokosi${day.getFullYear()}_${(day.getMonth() + 1)}_${day.getDate()}.txt`;

        // 引数のテキストまたは結果エリアのテキストを使用
        var textToSave = text || document.getElementById("result").textContent;

        // ここではBlobのインスタンスを作成しています。
        // Blobオブジェクトは不変の生のデータを表すオブジェクトです。テキストはバイナリデータを含むことができます。
        // Blobの最初の引数にテキストエリアから入手したtextを代入し、typeにテキストデータを指定しています。
        const blob = new Blob([textToSave], { type: "text/plain" });

        const url = URL.createObjectURL(blob);
        const a = document.createElement("a");
        // ここではURL.createObjectURL() を使用してしていされたオブジェクトを表すURLを含む文字列を作成します。
        // その作成したurlを別で作ったaタグのhrefに格納します。またdownlodに出力するファイル名を格納します。
        a.href = url;
        a.download = filename;

        // 作成したaタグをbody要素に追加して、クリックします。これによってファイルがダウンロードされます。
        document.body.appendChild(a);
        a.click();

        // 作成したaタグの削除とオブジェクトURLの開放を行います。
        document.body.removeChild(a);
        URL.revokeObjectURL(url);
    }

    // 結果エリアをクリア
    clear() {
        // 無を上書き
        var result = document.getElementById("result");
        result.innerText = "";
    }

    //サーバーにデータを送信する関数
    async sendToServer(text) {
        try {
            console.log("実際にサーバーに送ろうとしている文章「" + text + "」");

            const response = await fetch('/api/strings', {
                // HTTPメソッド
                method: 'POST',
                headers: {
                    // JSONデータであることを明示
                    'Content-Type': 'application/json',
                    'Accept': 'application/json'
                },
                // JavaScriptオブジェクトをJSON文字列に変換
                body: JSON.stringify({
                    // 送信したい文字列     
                    text: text,
                    // 追加情報（オプション）
                    timestamp: new Date().toISOString(),
                    // データの送信元情報（オプション）
                    source: 'client'
                })
            });

            // レスポンスの確認
            if (!response.ok) {
                throw new Error(`HTTP error! status: ${response.status}`);
            }

            // レスポンスをJSONとしてパース
            const result = await response.json();
            console.log('送信成功:', result);
            return result;

        } catch (error) {
            // エラー処理
            console.error('送信エラー:', error);
            console.log('サーバーへの送信に失敗しました: ' + error.message);
            throw error;
        }
    }

    // イベントリスナーを設定するクラス
    bindEvents() {
        document.addEventListener('DOMContentLoaded', () => {
            // 初期状態でgure_colorクラスを設定
            const moveItem = document.querySelector('.move_item');
            if (moveItem) {
                moveItem.classList.add('gure_color');
            }

            // 初期状態でtoggleElementのテキストを設定
            const toggleElement = document.getElementById('toggleElement');
            if (toggleElement) {
                toggleElement.innerHTML = 'NO RECORDING &emsp; &emsp; &emsp;  &emsp;  &emsp;  &emsp;  NO RECORDING &emsp; &emsp; &emsp;  &emsp;  &emsp;  &emsp;  NO RECORDING &emsp; &emsp; &emsp;  &emsp;  &emsp;  &emsp; NO RECORDING &emsp;  &emsp; &emsp;  &emsp;  &emsp;  &emsp; ';
            }

            // 初期状態でボタンの状態を設定
            this.resetButtonStates();

            // 開始ボタンを押すとrecognitionの機能がスタートする
            document.getElementById("start").addEventListener("click", () => {
                this.startRecognition();
            });

            // 停止ボタンを押すと停止する
            document.getElementById("stop").addEventListener("click", () => {
                this.stopRecognition();
            });

            // エクスポートボタンを押すとエクスポートできる
            const exportButton = document.getElementById("export");
            if (exportButton) {
                exportButton.addEventListener("click", () => {
                    this.save();
                });
            }

            // クリアボタンを押すと表示がクリアされる
            const clearButton = document.getElementById("clear");
            if (clearButton) {
                clearButton.addEventListener("click", () => {
                    this.clear();
                });
            }
        });
    }
}

// 翻訳のAPIを借りた場所 https://mt-auto-minhon-mlt.ucri.jgn-x.jp/content/api/
// 翻訳のコード参考 https://makky12.hatenablog.com/entry/2022/07/04/120500

// 翻訳機能を管理するクラス
class TranslationManager {
    constructor() {
        this.isTranslating = false;
        this.translationInterval = null;
        this.lastTranslatedText = '';
    }

    // 翻訳を開始
    startTranslation() {
        if (this.isTranslating) {
            console.log('翻訳は既に開始されています');
            return;
        }

        this.isTranslating = true;
        console.log('翻訳を開始しました');

        // 翻訳エリアを表示
        this.switchToDualView();

        // 翻訳ボタンの状態を変更
        const translationBtn = document.getElementById("translation");
        if (translationBtn) {
            translationBtn.innerHTML = '<span>翻訳停止</span>';
            translationBtn.classList.add('translation-active');
        }

        // 翻訳結果エリアに開始メッセージを表示
        const translationResult = document.getElementById("translation-result");
        if (translationResult) {
            translationResult.textContent = '翻訳を開始します...';
        }

        // 5秒間隔で翻訳を実行
        this.translationInterval = setInterval(() => {
            this.performTranslation();
        }, 5000);

        // 初回実行
        this.performTranslation();
    }

    // 翻訳を停止
    stopTranslation() {
        if (!this.isTranslating) {
            console.log('翻訳は開始されていません');
            return;
        }

        this.isTranslating = false;
        console.log('翻訳を停止しました');

        // インターバルをクリア
        if (this.translationInterval) {
            clearInterval(this.translationInterval);
            this.translationInterval = null;
        }

        // シングルに戻す
        this.switchToSingleView();

        // 翻訳ボタンの状態を戻す
        const translationBtn = document.getElementById("translation");
        if (translationBtn) {
            translationBtn.innerHTML = '<span>日→英翻訳</span>';
            translationBtn.classList.remove('translation-active');
        }
    }

    // 翻訳の切り替え
    toggleTranslation() {
        if (this.isTranslating) {
            this.stopTranslation();
        } else {
            this.startTranslation();
        }
    }

    // resultのみ表示する場合の関数
    switchToSingleView() {
        const container = document.getElementById("translation-container");
        const labels = document.getElementById("translation-labels");
        
        if (container) {
            container.classList.remove('dual-view');
            container.classList.add('single-view');
        }
        
        if (labels) {
            labels.classList.remove('show');
        }
    }

    // resultとtrans_resultを横並び表示するときの関数
    switchToDualView() {
        const container = document.getElementById("translation-container");
        const labels = document.getElementById("translation-labels");
        
        if (container) {
            container.classList.remove('single-view');
            container.classList.add('dual-view');
        }
        
        if (labels) {
            labels.classList.add('show');
        }
    }

    // 実際の翻訳処理を実行
    async performTranslation() {
        const resultElement = document.getElementById("result");
        const translationResultElement = document.getElementById("translation-result");
        
        if (!resultElement || !translationResultElement) {
            console.error('必要な要素が見つかりません');
            return;
        }

        const currentText = resultElement.textContent.trim();
        
        // テキストが空の場合や前回と同じ場合はスキップ
        if (!currentText || currentText === this.lastTranslatedText) {
            return;
        }

        try {
            console.log('翻訳を開始:', currentText);
            translationResultElement.textContent = '翻訳中...';

            // サーバーに翻訳リクエストを送信
            const response = await fetch('/api/translate', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                    'Accept': 'application/json'
                },
                body: JSON.stringify({
                    text: currentText,
                    timestamp: new Date().toISOString()
                })
            });

            if (!response.ok) {
                throw new Error(`HTTP error! status: ${response.status}`);
            }

            const result = await response.json();
            
            if (result.success && result.translated) {
                // 翻訳結果を表示
                translationResultElement.textContent = result.translated;
                this.lastTranslatedText = currentText;
                console.log('翻訳完了:', result.translated);
                
                // スクロールを一番下に移動
                translationResultElement.scrollTop = translationResultElement.scrollHeight;
            } else {
                throw new Error(result.error || '翻訳に失敗しました');
            }

        } catch (error) {
            console.error('翻訳エラー:', error);
            translationResultElement.textContent = `翻訳エラー: ${error.message}`;
        }
    }

    // 翻訳結果をクリア
    clearTranslationResult() {
        const translationResult = document.getElementById("translation-result");
        if (translationResult) {
            translationResult.textContent = '';
            this.lastTranslatedText = '';
        }
    }

    cleanup() {
        if (this.translationInterval) {
            clearInterval(this.translationInterval);
        }
        this.isTranslating = false;
    }
}

// グローバルインスタンスを作成
const translationManager = new TranslationManager();

// 既存のSpeechTranscriptionToolクラスの翻訳ボタンイベントを更新する関数
function updateTranslationButtonEvent() {
    const translationButton = document.getElementById("translation");
    if (translationButton) {
        // 既存のイベントリスナーを削除
        translationButton.removeEventListener("click", translationManager.toggleTranslation);
        // 新しいイベントリスナーを追加
        translationButton.addEventListener("click", () => {
            translationManager.toggleTranslation();
        });
    }
}

// コピー関数
function copyButton(elementId) {
    const speechTool = new SpeechTranscriptionTool();
    speechTool.copyButton(elementId);
}

// DOMが読み込まれた後に翻訳ボタンのイベントを設定
document.addEventListener('DOMContentLoaded', () => {
    updateTranslationButtonEvent();
    
    // 既存のクリアボタンに翻訳結果のクリア機能も追加
    const clearButton = document.getElementById("clear");
    if (clearButton) {
        clearButton.addEventListener("click", () => {
            translationManager.clearTranslationResult();
        });
    }
});

// クラスのインスタンスを作成して初期化
const speechTool = new SpeechTranscriptionTool();