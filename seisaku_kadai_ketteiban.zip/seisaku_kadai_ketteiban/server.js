// いろいろ定義
const express = require('express')
const app = express()
const port = 2380;
const path = require('path');
const fs = require('fs').promises;
const rateLimit = require('express-rate-limit');
const helmet = require('helmet');
const validator = require('validator');
const xss = require('xss');

// 翻訳機能をインポート
const { translate } = require('./honyaku.js');

// JSONファイルのパス
const DATA_FILE = path.join(__dirname, '/public/speech_data.json');
const TRANSLATION_LOG_FILE = path.join(__dirname, '/public/translation_log.json');

// ミドルウェアの設定
app.use(express.json({ limit: '1mb' })); // JSONボディパーサー
app.use(express.static(path.join(__dirname, 'public'))); // 静的ファイルの配信

// セキュリティミドルウェアの設定
app.use(helmet()); // 基本的なセキュリティヘッダーを設定

// レート制限の設定
const limiter = rateLimit({
    windowMs: 15 * 60 * 1000, // 15分
    max: 100, // 最大100リクエスト
    message: {
        error: 'リクエストが多すぎます',
        message: '15分後に再試行してください'
    }
});

// 翻訳専用のレート制限（より厳しく設定）
const translationLimiter = rateLimit({
    windowMs: 1 * 60 * 1000, // 1分
    max: 20, // 最大20リクエスト（翻訳APIの負荷を考慮）
    message: {
        error: '翻訳リクエストが多すぎます',
        message: '1分後に再試行してください'
    }
});

app.use('/api/', limiter);

// 文字列検証関数
function validateString(text) {
    const errors = [];
    
    // 基本的な検証
    if (!text || typeof text !== 'string') {
        errors.push('有効な文字列が必要です');
        return { isValid: false, errors };
    }
    
    // 長さの検証
    if (text.length < 1) {
        errors.push('文字列は1文字以上である必要があります');
    }
    
    if (text.length > 10000) {
        errors.push('文字列は10,000文字以下である必要があります');
    }
    
    // 悪意のあるスクリプトの検証
    if (/<script[^>]*>.*?<\/script>/gi.test(text)) {
        errors.push('スクリプトタグは許可されていません');
    }
    
    // SQLインジェクションの基本的な検証
    const sqlPatterns = [
        /union\s+select/gi,
        /drop\s+table/gi,
        /delete\s+from/gi,
        /insert\s+into/gi
    ];
    
    for (const pattern of sqlPatterns) {
        if (pattern.test(text)) {
            errors.push('不正なSQL文字列が検出されました');
            break;
        }
    }
    
    // 禁止文字の検証
    const forbiddenChars = ['\0', '\x1a'];
    for (const char of forbiddenChars) {
        if (text.includes(char)) {
            errors.push('禁止文字が含まれています');
            break;
        }
    }
    
    return {
        isValid: errors.length === 0,
        errors,
        sanitized: xss(text) // XSS対策でサニタイズ
    };
}

// 高度な検証機能 
function advancedValidation(text, options = {}) {
    const result = validateString(text);
    
    if (!result.isValid) {
        return result;
    }
    
    const advanced = {
        ...result,
        statistics: {
            characterCount: text.length,
            wordCount: text.split(/\s+/).filter(w => w.length > 0).length,
            lineCount: text.split('\n').length,
            paragraphCount: text.split(/\n\s*\n/).length,
            hasSpecialChars: /[!@#$%^&*(),.?":{}|<>]/.test(text),
            hasNumbers: /\d/.test(text),
            hasUpperCase: /[A-Z]/.test(text),
            hasLowerCase: /[a-z]/.test(text),
            hasJapanese: /[\u3040-\u309f\u30a0-\u30ff\u4e00-\u9faf]/.test(text),
            encoding: 'UTF-8'
        }
    };
    
    // カスタムバリデーション
    if (options.minWords && advanced.statistics.wordCount < options.minWords) {
        advanced.errors.push(`最低${options.minWords}語必要です`);
        advanced.isValid = false;
    }
    
    if (options.maxWords && advanced.statistics.wordCount > options.maxWords) {
        advanced.errors.push(`最大${options.maxWords}語までです`);
        advanced.isValid = false;
    }
    
    if (options.requireJapanese && !advanced.statistics.hasJapanese) {
        advanced.errors.push('日本語が必要です');
        advanced.isValid = false;
    }
    
    return advanced;
}

// データをJSONファイルに保存する関数
async function saveStringSecurely(text, metadata) {
    try {
        // 既存のデータを読み込み
        let existingData = [];
        try {
            const fileData = await fs.readFile(DATA_FILE, 'utf8');
            existingData = JSON.parse(fileData);
        } catch (error) {
            // ファイルが存在しない場合は空の配列を使用
            if (error.code !== 'ENOENT') {
                throw error;
            }
        }
        
        // 新しいデータを追加
        const newEntry = {
            id: Date.now(),
            text: text,
            metadata: metadata,
            createdAt: new Date().toISOString()
        };
        
        existingData.push(newEntry);
        
        // ファイルに保存
        await fs.writeFile(DATA_FILE, JSON.stringify(existingData, null, 2));
        
        return newEntry;
    } catch (error) {
        console.error('データ保存エラー:', error);
        throw new Error('データの保存に失敗しました');
    }
}

// 翻訳ログを保存する関数
async function saveTranslationLog(originalText, translatedText, success, error = null) {
    try {
        let existingLogs = [];
        try {
            const fileData = await fs.readFile(TRANSLATION_LOG_FILE, 'utf8');
            existingLogs = JSON.parse(fileData);
        } catch (error) {
            if (error.code !== 'ENOENT') {
                throw error;
            }
        }
        
        const logEntry = {
            id: Date.now(),
            originalText: originalText.substring(0, 200) + (originalText.length > 200 ? '...' : ''), // 長すぎる場合は省略
            translatedText: success ? translatedText : null,
            success: success,
            error: error,
            timestamp: new Date().toISOString(),
            characterCount: originalText.length
        };
        
        existingLogs.push(logEntry);
        
        // ログファイルが大きくなりすぎないよう、最新の100件のみ保持
        if (existingLogs.length > 100) {
            existingLogs = existingLogs.slice(-100);
        }
        
        await fs.writeFile(TRANSLATION_LOG_FILE, JSON.stringify(existingLogs, null, 2));
        
    } catch (error) {
        console.error('翻訳ログ保存エラー:', error);
    }
}

// 基本的な文字列保存エンドポイント（script.jsから呼ばれる）
app.post('/api/strings', async (req, res) => {
    try {
        const { text, timestamp, source } = req.body;
        
        // 基本的な検証
        const validation = validateString(text);
        
        if (!validation.isValid) {
            return res.status(400).json({
                error: '文字列の検証に失敗しました',
                details: validation.errors
            });
        }
        
        // データを保存
        const savedData = await saveStringSecurely(validation.sanitized, {
            originalLength: text.length,
            sanitizedLength: validation.sanitized.length,
            timestamp,
            source,
            clientIP: req.ip,
            userAgent: req.get('User-Agent')
        });
        
        res.status(201).json({
            success: true,
            message: '文字列が保存されました',
            data: {
                id: savedData.id,
                text: savedData.text,
                createdAt: savedData.createdAt
            }
        });
        
    } catch (error) {
        console.error('保存エラー:', error);
        res.status(500).json({
            error: 'サーバーエラー',
            message: 'データの処理中にエラーが発生しました'
        });
    }
});

// 翻訳エンドポイント
app.post('/api/translate', translationLimiter, async (req, res) => {
    try {
        const { text, timestamp } = req.body;
        
        console.log('翻訳リクエスト受信:', { text: text?.substring(0, 50) + '...', timestamp });
        
        // 入力検証
        const validation = validateString(text);
        
        if (!validation.isValid) {
            await saveTranslationLog(text, null, false, '入力検証エラー: ' + validation.errors.join(', '));
            return res.status(400).json({
                success: false,
                error: '入力文字列の検証に失敗しました',
                details: validation.errors
            });
        }
        
        // 翻訳対象のテキストが空の場合
        const sanitizedText = validation.sanitized.trim();
        if (!sanitizedText) {
            return res.json({
                success: true,
                original: text,
                translated: '',
                message: '翻訳対象のテキストが空です'
            });
        }
        
        // 翻訳実行
        console.log('翻訳処理開始:', sanitizedText);
        const translationResult = await translate(sanitizedText);
        
        if (translationResult.success) {
            // 翻訳成功
            console.log('翻訳成功:', translationResult.translated);
            await saveTranslationLog(sanitizedText, translationResult.translated, true);
            
            res.json({
                success: true,
                original: sanitizedText,
                translated: translationResult.translated,
                timestamp: new Date().toISOString()
            });
        } else {
            // 翻訳失敗
            console.error('翻訳失敗:', translationResult.error);
            await saveTranslationLog(sanitizedText, null, false, translationResult.error);
            
            res.status(500).json({
                success: false,
                error: '翻訳に失敗しました',
                details: translationResult.error,
                original: sanitizedText
            });
        }
        
    } catch (error) {
        console.error('翻訳エンドポイントエラー:', error);
        await saveTranslationLog(req.body?.text || '', null, false, error.message);
        
        res.status(500).json({
            success: false,
            error: 'サーバーエラー',
            message: '翻訳処理中にエラーが発生しました',
            details: error.message
        });
    }
});

// 翻訳ログを取得するエンドポイント
app.get('/api/translate/logs', async (req, res) => {
    try {
        const fileData = await fs.readFile(TRANSLATION_LOG_FILE, 'utf8');
        const logs = JSON.parse(fileData);
        
        res.json({
            success: true,
            logs: logs,
            count: logs.length
        });
    } catch (error) {
        if (error.code === 'ENOENT') {
            res.json({
                success: true,
                logs: [],
                count: 0
            });
        } else {
            console.error('翻訳ログ取得エラー:', error);
            res.status(500).json({
                success: false,
                error: '翻訳ログの取得に失敗しました'
            });
        }
    }
});

// 安全な文字列処理エンドポイント
app.post('/api/strings/secure', async (req, res) => {
    try {
        const { text, options = {} } = req.body;
        
        // 検証実行
        const validation = advancedValidation(text, options);
        
        if (!validation.isValid) {
            return res.status(400).json({
                error: '文字列の検証に失敗しました',
                details: validation.errors,
                statistics: validation.statistics
            });
        }
        
        // サニタイズされた文字列を使用
        const safeText = validation.sanitized;
        
        // データベースに安全に保存
        const savedData = await saveStringSecurely(safeText, {
            originalLength: text.length,
            sanitizedLength: safeText.length,
            statistics: validation.statistics,
            clientIP: req.ip,
            userAgent: req.get('User-Agent'),
            timestamp: new Date().toISOString()
        });
        
        res.status(201).json({
            success: true,
            message: '文字列が安全に保存されました',
            data: savedData,
            validation: {
                passed: true,
                statistics: validation.statistics
            }
        });
        
    } catch (error) {
        console.error('セキュア処理エラー:', error);
        res.status(500).json({
            error: 'サーバーエラー',
            message: 'データの処理中にエラーが発生しました'
        });
    }
});

// 保存されたデータを取得するエンドポイント
app.get('/api/strings', async (req, res) => {
    try {
        const fileData = await fs.readFile(DATA_FILE, 'utf8');
        const data = JSON.parse(fileData);
        
        res.json({
            success: true,
            data: data,
            count: data.length
        });
    } catch (error) {
        if (error.code === 'ENOENT') {
            // ファイルが存在しない場合
            res.json({
                success: true,
                data: [],
                count: 0
            });
        } else {
            console.error('データ取得エラー:', error);
            res.status(500).json({
                error: 'データの取得に失敗しました'
            });
        }
    }
});

// 特定のIDのデータを削除するエンドポイント
app.delete('/api/strings/:id', async (req, res) => {
    try {
        const targetId = parseInt(req.params.id, 10);
        
        if (isNaN(targetId)) {
            return res.status(400).json({
                error: '無効なIDです',
                message: 'IDは数値である必要があります'
            });
        }
        
        // 既存のデータを読み込み
        let existingData = [];
        try {
            const fileData = await fs.readFile(DATA_FILE, 'utf8');
            existingData = JSON.parse(fileData);
        } catch (error) {
            if (error.code === 'ENOENT') {
                return res.status(404).json({
                    error: 'データファイルが見つかりません'
                });
            }
            throw error;
        }
        
        // 削除対象のデータを検索
        const targetItem = existingData.find(item => parseInt(item.id, 10) === targetId);
        
        if (!targetItem) {
            return res.status(404).json({
                error: '指定されたIDのデータが見つかりません',
                id: targetId
            });
        }
        
        // 指定されたIDのデータを除外した新しい配列を作成
        const filteredData = existingData.filter(item => parseInt(item.id, 10) !== targetId);
        
        // ファイルに保存
        await fs.writeFile(DATA_FILE, JSON.stringify(filteredData, null, 2));
        
        res.json({
            success: true,
            message: 'データが削除されました',
            deletedItem: {
                id: targetItem.id,
                text: targetItem.text.substring(0, 50) + (targetItem.text.length > 50 ? '...' : ''),
                createdAt: targetItem.createdAt
            },
            remainingCount: filteredData.length
        });
        
    } catch (error) {
        console.error('削除エラー:', error);
        res.status(500).json({
            error: 'サーバーエラー',
            message: 'データの削除中にエラーが発生しました'
        });
    }
});

// ルートエンドポイント
app.get('/', (req, res) => {
    res.sendFile(path.join(__dirname, 'public', 'index.html'));
});

app.listen(port, () => {
    console.log(`Example app listening on port ${port}`);
});
