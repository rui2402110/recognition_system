const https = require('https');
const url = require('url');
const querystring = require('querystring');

// API設定
const CONFIG = {
    base_domain: 'https://mt-auto-minhon-mlt.ucri.jgn-x.jp',
    api_endpoint: '/api/mt/generalNT_ja_en/',
    token_endpoint: '/oauth2/token.php',
    key: 'c43f7d5aff2f0b7bf327a2b9ac8fa73f06848e0f7',
    secret: 'abc77fe63391dd35224c179b40749de6',
    name: 'hakaitun',
    api_name: 'mt',
    api_param: 'generalNT_ja_en'
};

class TranslationService {
    constructor() {
        this.access_token = null;
        this.token_expires_at = null;
    }

    // HTTPSリクエストを送信する関数
    makeRequest(options, postData = null) {
        return new Promise((resolve, reject) => {
            const req = https.request(options, (res) => {
                let data = '';
                
                res.on('data', (chunk) => {
                    data += chunk;
                });
                
                res.on('end', () => {
                    resolve({
                        statusCode: res.statusCode,
                        body: data,
                        headers: res.headers
                    });
                });
            });
            
            req.on('error', (err) => {
                reject(err);
            });
            
            if (postData) {
                req.write(postData);
            }
            
            req.end();
        });
    }

    // アクセストークンが有効かチェック
    isTokenValid() {
        return this.access_token && 
               this.token_expires_at && 
               Date.now() < this.token_expires_at;
    }

    // アクセストークンを取得する関数
    async getAccessToken() {
        const tokenParams = {
            grant_type: 'client_credentials',
            client_id: CONFIG.key,
            client_secret: CONFIG.secret
        };
        
        const postData = querystring.stringify(tokenParams);
        const parsedUrl = url.parse(CONFIG.base_domain + CONFIG.token_endpoint);
        
        const options = {
            hostname: parsedUrl.hostname,
            port: 443,
            path: parsedUrl.path,
            method: 'POST',
            headers: {
                'Content-Type': 'application/x-www-form-urlencoded',
                'Content-Length': Buffer.byteLength(postData)
            }
        };
        
        try {
            const response = await this.makeRequest(options, postData);
            
            if (response.statusCode === 200) {
                const tokenData = JSON.parse(response.body);
                this.access_token = tokenData.access_token;
                
                // トークンの有効期限を設定（通常1時間、少し短めに設定）
                const expiresIn = tokenData.expires_in || 3600;
                this.token_expires_at = Date.now() + (expiresIn - 300) * 1000; // 5分早めに期限切れとする
                
                if (this.access_token) {
                    return { success: true };
                } else {
                    return { 
                        success: false, 
                        error: 'レスポンスにaccess_tokenが含まれていません' 
                    };
                }
            } else {
                return { 
                    success: false, 
                    error: `トークン取得エラー: HTTP ${response.statusCode}` 
                };
            }
        } catch (err) {
            return { 
                success: false, 
                error: `トークン取得リクエストエラー: ${err.message}` 
            };
        }
    }

    // 翻訳APIを呼び出す関数
    async translateText(textToTranslate) {
        // 入力値の検証
        if (!textToTranslate || typeof textToTranslate !== 'string') {
            return {
                success: false,
                error: '翻訳するテキストが指定されていないか、文字列ではありません',
                original: textToTranslate,
                translated: null
            };
        }

        // 空文字列の場合
        if (textToTranslate.trim() === '') {
            return {
                success: true,
                original: textToTranslate,
                translated: ''
            };
        }

        // アクセストークンの確認・取得
        if (!this.isTokenValid()) {
            const tokenResult = await this.getAccessToken();
            if (!tokenResult.success) {
                return {
                    success: false,
                    error: `アクセストークン取得失敗: ${tokenResult.error}`,
                    original: textToTranslate,
                    translated: null
                };
            }
        }

        const params = {
            access_token: this.access_token,
            key: CONFIG.key,
            api_name: CONFIG.api_name,
            api_param: CONFIG.api_param,
            name: CONFIG.name,
            type: 'json',
            text: textToTranslate
        };
        
        const postData = querystring.stringify(params);
        const parsedUrl = url.parse(CONFIG.base_domain + CONFIG.api_endpoint + 'api/');
        
        const options = {
            hostname: parsedUrl.hostname,
            port: 443,
            path: parsedUrl.path,
            method: 'POST',
            headers: {
                'Content-Type': 'application/x-www-form-urlencoded',
                'Content-Length': Buffer.byteLength(postData)
            }
        };
        
        try {
            const response = await this.makeRequest(options, postData);
            
            if (response.statusCode === 200) {
                const result = JSON.parse(response.body);
                
                if (result.resultset && result.resultset.result) {
                    return {
                        success: true,
                        original: textToTranslate,
                        translated: result.resultset.result.text
                    };
                } else {
                    return {
                        success: false,
                        error: '予期しないレスポンス形式です',
                        original: textToTranslate,
                        translated: null
                    };
                }
            } else {
                return {
                    success: false,
                    error: `HTTP ${response.statusCode}: ${response.body}`,
                    original: textToTranslate,
                    translated: null
                };
            }
        } catch (err) {
            return {
                success: false,
                error: `リクエストエラー: ${err.message}`,
                original: textToTranslate,
                translated: null
            };
        }
    }

    // 複数のテキストを一括翻訳
    async translateMultiple(texts) {
        if (!Array.isArray(texts)) {
            return {
                success: false,
                error: 'テキストの配列を指定してください'
            };
        }

        const results = [];
        for (const text of texts) {
            const result = await this.translateText(text);
            results.push(result);
        }

        return {
            success: true,
            results: results,
            successCount: results.filter(r => r.success).length,
            totalCount: results.length
        };
    }
}

// シングルトンインスタンス
const translationService = new TranslationService();

// 簡単に使える関数をエクスポート
async function translate(text) {
    return await translationService.translateText(text);
}

async function translateMultiple(texts) {
    return await translationService.translateMultiple(texts);
}

// クラスベースの使用も可能
function createTranslationService() {
    return new TranslationService();
}

module.exports = {
    translate,
    translateMultiple,
    TranslationService,
    createTranslationService
};